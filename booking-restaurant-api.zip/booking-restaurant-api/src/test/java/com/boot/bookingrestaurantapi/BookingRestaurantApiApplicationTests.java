package com.boot.bookingrestaurantapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingRestaurantApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
